# Usage

Simply run `python3 main.py` from `/code`

This will reproduce all mosaic images inside `/images`